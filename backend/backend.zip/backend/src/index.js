import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serve } from '@hono/node-server'

const app = new Hono()

app.use('/*', cors({
  origin: ['https://cloudmiami.com', 'http://localhost:5173'],
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}))

app.get('/', (c) => c.json({ 
  service: 'Cloud Miami API',
  version: '1.0.0',
  status: 'running',
}))

app.post('/api/chat/stream', async (c) => {
  const body = await c.req.json()
  const { message } = body

  if (!message) {
    return c.json({ error: 'Message is required' }, 400)
  }

  const response = `Hi! I am the Cloud Miami AI assistant. You asked about: "${message}". 

How can I help you learn about our services? We specialize in:
- Modern web architecture with React
- SEO and content marketing
- Professional video production

Would you like to schedule a discovery call to discuss your needs?`

  const encoder = new TextEncoder()
  const stream = new ReadableStream({
    start(controller) {
      controller.enqueue(encoder.encode(response))
      controller.close()
    },
  })

  return new Response(stream, {
    headers: { 'Content-Type': 'text/plain; charset=utf-8' },
  })
})

app.post('/api/chat/complete', async (c) => {
  const body = await c.req.json()
  const { message } = body

  return c.json({ 
    response: `Cloud Miami can help you with: "${message}". Contact us to learn more!` 
  })
})

app.post('/api/chat/lead', async (c) => {
  const body = await c.req.json()
  const { name, email } = body

  if (!name || !email) {
    return c.json({ error: 'Name and email are required' }, 400)
  }

  return c.json({ success: true, lead: { name, email } })
})

app.post('/api/chat/search', async (c) => {
  return c.json({ results: [] })
})

const PORT = process.env.PORT || 3000

console.log(`Server running on port ${PORT}`)

serve({
  fetch: app.fetch,
  port: PORT,
})
